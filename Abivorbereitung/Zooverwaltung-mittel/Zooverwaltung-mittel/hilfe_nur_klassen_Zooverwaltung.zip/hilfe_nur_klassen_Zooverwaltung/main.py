# main.py (Hauptprogramm)
from fleischfresser import Fleischfresser
from pflanzenfresser import Pflanzenfresser
from allesfresser import Allesfresser

def main():
    pass
    
if __name__ == "__main__": #main wird nur gestartet, wenn man es direkt in main ausführt
    main()
