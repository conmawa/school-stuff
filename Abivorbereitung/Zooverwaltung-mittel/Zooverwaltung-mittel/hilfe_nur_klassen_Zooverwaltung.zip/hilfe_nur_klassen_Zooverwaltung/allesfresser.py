# allesfresser.py (Unterklasse Allesfresser)
from tier import Tier

class Allesfresser(Tier):
    def berechne_futtermenge(self):
        pass
