# tier.py (Basisklasse Tier)
from abc import ABC, abstractmethod

class Tier(ABC):
    def __init__(self, name, art, gewicht):
        pass
    
    # Getter-Methoden für die Attribute
    def get_name(self):
        pass
    
    def get_art(self):
        pass
    
    def get_gewicht(self):
        pass
    
    # Setter-Methode für das Gewicht mit Prüfung
    def set_gewicht(self, gewicht):
        pass
    
    # Abstrakte Methode für die Futterberechnung
    @abstractmethod
    def berechne_futtermenge(self):
        pass #hier bleibt einfach pass drin und wird in Unterklassen überschrieben