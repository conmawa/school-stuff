# fleischfresser.py (Unterklasse Fleischfresser)
from tier import Tier

class Fleischfresser(Tier):
    def berechne_futtermenge(self):
        pass