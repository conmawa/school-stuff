# tier.py (Basisklasse Tier)
from abc import ABC, abstractmethod

class Tier(ABC):
    def __init__(self, name, art, gewicht):
        self.__name = name  # Name des Tieres (z. B. Simba, Dumbo)
        self.__art = art  # Tierart (z. B. Löwe, Elefant)
        self.set_gewicht(gewicht)  # Gewicht mit Validierung
    
    # Getter-Methoden für die Attribute
    def get_name(self):
        return self.__name
    
    def get_art(self):
        return self.__art
    
    def get_gewicht(self):
        return self.__gewicht
    
    # Setter-Methode für das Gewicht mit Prüfung
    def set_gewicht(self, gewicht):
        if gewicht <= 0:
            raise ValueError("Das Gewicht muss positiv sein!")
        self.__gewicht = gewicht
    
    # Abstrakte Methode für die Futterberechnung
    @abstractmethod
    def berechne_futtermenge(self):
        pass