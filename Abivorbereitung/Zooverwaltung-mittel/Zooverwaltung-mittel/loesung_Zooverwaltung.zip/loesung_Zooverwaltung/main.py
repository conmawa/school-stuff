# main.py (Hauptprogramm)
from fleischfresser import Fleischfresser
from pflanzenfresser import Pflanzenfresser
from allesfresser import Allesfresser

def main():
    # Beispiel-Tiere erstellen
    loewe = Fleischfresser("Simba", "Löwe", 120)
    elefant = Pflanzenfresser("Dumbo", "Elefant", 5000)
    baer = Allesfresser("Baloo", "Bär", 300)
    
    # Nutzer wählt ein Tier aus
    print("Wählen Sie ein Tier: 1 = Löwe, 2 = Elefant, 3 = Bär")
    tier_typ = input("Eingabe: ")
    
    if tier_typ == "1":
        tier = loewe
    elif tier_typ == "2":
        tier = elefant
    elif tier_typ == "3":
        tier = baer
    else:
        print("Ungültige Eingabe.")
        return
    
    # Berechnung der Futtermenge
    futter = tier.berechne_futtermenge()
    
    # Ausgabe der Futtermenge
    if isinstance(tier, Allesfresser):
        print(f"\n{tier.get_name()} ({tier.get_art()}) benötigt täglich:")
        print(f"{futter[0]:.2f} kg Fleisch und {futter[1]:.2f} kg Pflanzen.")
    else:
        futterart = "Fleisch" if isinstance(tier, Fleischfresser) else "Pflanzen"
        print(f"\n{tier.get_name()} ({tier.get_art()}) benötigt täglich {futter:.2f} kg {futterart}.")
    
if __name__ == "__main__": #main wird nur gestartet, wenn man es direkt in main ausführt
    main()
