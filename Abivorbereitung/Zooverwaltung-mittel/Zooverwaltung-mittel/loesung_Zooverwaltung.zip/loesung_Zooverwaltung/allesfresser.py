# allesfresser.py (Unterklasse Allesfresser)
from tier import Tier

class Allesfresser(Tier):
    def berechne_futtermenge(self):
        # Allesfresser brauchen 1 kg Fleisch + 2 kg Pflanzen pro 10 kg Körpergewicht
        fleisch = (self.get_gewicht() / 10) * 1  # Fleisch in kg
        pflanzen = (self.get_gewicht() / 10) * 2  # Pflanzen in kg
        return fleisch, pflanzen
