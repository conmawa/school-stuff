# pflanzenfresser.py (Unterklasse Pflanzenfresser)
from tier import Tier

class Pflanzenfresser(Tier):
    def berechne_futtermenge(self):
        # Pflanzenfresser brauchen 3 kg Pflanzen pro 10 kg Körpergewicht
        return (self.get_gewicht() / 10) * 3  # Pflanzen in kg