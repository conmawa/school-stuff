# fleischfresser.py (Unterklasse Fleischfresser)
from tier import Tier

class Fleischfresser(Tier):
    def berechne_futtermenge(self):
        # Fleischfresser brauchen 1 kg Fleisch pro 10 kg Körpergewicht
        return (self.get_gewicht() / 10) * 1  # Fleisch in kg