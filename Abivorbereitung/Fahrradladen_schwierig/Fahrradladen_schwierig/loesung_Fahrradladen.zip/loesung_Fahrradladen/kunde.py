
# kunde.py (Kunden-Klasse)
class Kunde:
    def __init__(self, name):
        self.name = name  # Name des Kunden
        self.gekaufte_fahrraeder = []  # Liste der gekauften Fahrräder
        self.gemietete_fahrraeder = {}  # Dictionary für gemietete Fahrräder mit Mietdauer
    
    def kaufe_fahrrad(self, fahrrad):
        """Kauft ein Fahrrad und entfernt es aus dem Bestand."""
        if fahrrad.verfuegbar:
            self.gekaufte_fahrraeder.append(fahrrad)
            fahrrad.verfuegbar = False
            print(f"{self.name} hat ein {fahrrad.get_marke()} {fahrrad.get_modell()} für {fahrrad.get_preis()} € gekauft.")
        else:
            print("Fahrrad nicht verfügbar.")
    
    def miete_fahrrad(self, fahrrad, tage):
        """Mietet ein Fahrrad für eine bestimmte Anzahl an Tagen."""
        if fahrrad.verfuegbar:
            kosten = fahrrad.get_mietgebuehr() * tage
            self.gemietete_fahrraeder[fahrrad.get_modell().lower()] = fahrrad
            fahrrad.verfuegbar = False
            print(f"{self.name} hat ein {fahrrad.get_marke()} {fahrrad.get_modell()} für {tage} Tage gemietet. Kosten: {kosten} €")
        else:
            print("Fahrrad ist nicht verfügbar.")
    
    def rueckgabe_fahrrad(self, modell, tage_zu_spaet):
        """Gibt ein Fahrrad zurück und berechnet eine Strafgebühr bei Verspätung."""
        modell = modell.lower()
        if modell in self.gemietete_fahrraeder:
            fahrrad = self.gemietete_fahrraeder[modell]
            strafe = 5 * tage_zu_spaet if tage_zu_spaet > 0 else 0
            fahrrad.verfuegbar = True
            del self.gemietete_fahrraeder[modell]
            print(f"{self.name} hat das {fahrrad.get_marke()} {modell} zurückgegeben. Strafgebühr: {strafe} €")
        else:
            print("Dieses Fahrrad wurde nicht von diesem Kunden gemietet.")