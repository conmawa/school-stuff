# citybike.py (Unterklasse Citybike)
from fahrrad import Fahrrad

class Citybike(Fahrrad):
    def __init__(self, marke, preis):
        super().__init__(marke, "Citybike", preis, mietgebuehr=10)  # Citybikes sind günstiger
        self.gepaecktraeger = True  # Citybikes haben einen Gepäckträger
    
    def fahrrad_info(self):
        return f"{self.get_marke()} {self.get_modell()} - Gepäckträger: {self.gepaecktraeger}"