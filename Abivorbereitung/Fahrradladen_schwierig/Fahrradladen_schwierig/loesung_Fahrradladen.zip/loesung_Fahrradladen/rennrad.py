# rennrad.py (Unterklasse Rennrad)
from fahrrad import Fahrrad

class Rennrad(Fahrrad):
    def __init__(self, marke, preis):
        super().__init__(marke, "Rennrad", preis, mietgebuehr=20)  # Rennräder sind am teuersten
        self.gewicht = 8  # Standardgewicht in kg
    
    def fahrrad_info(self):
        return f"{self.get_marke()} {self.get_modell()} - Gewicht: {self.gewicht} kg"