# fahrradladen.py (Lagerbestand und Verwaltung)
class Fahrradladen:
    def __init__(self):
        self.bestand = []  # Liste der Fahrräder im Laden
    
    def neues_fahrrad_hinzufuegen(self, fahrrad):
        self.bestand.append(fahrrad)
    
    def fahrrad_verfuegbar(self, modell):
        for fahrrad in self.bestand:
            if fahrrad.get_modell().lower() == modell and fahrrad.verfuegbar:
                return fahrrad
        return None
    
    def anzeigen_bestand(self):
        print("\nAktueller Fahrradbestand:")
        for fahrrad in self.bestand:
            status = "Verfügbar" if fahrrad.verfuegbar else "Nicht verfügbar"
            print(f"{fahrrad.get_marke()} {fahrrad.get_modell()} - Preis: {fahrrad.get_preis()} € - {status}")