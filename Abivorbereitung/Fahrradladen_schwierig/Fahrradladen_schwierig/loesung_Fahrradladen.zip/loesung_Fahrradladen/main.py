# main.py (Hauptprogramm)
from citybike import Citybike
from mountainbike import Mountainbike
from rennrad import Rennrad
from kunde import Kunde
from fahrradladen import Fahrradladen

def main():
    # Fahrradladen erstellen
    laden = Fahrradladen()
    
    # Fahrräder hinzufügen
    citybike = Citybike("Cube", 500)
    mountainbike = Mountainbike("Giant", 1200)
    rennrad = Rennrad("Scott", 2500)
    laden.neues_fahrrad_hinzufuegen(citybike)
    laden.neues_fahrrad_hinzufuegen(mountainbike)
    laden.neues_fahrrad_hinzufuegen(rennrad)
    
    # Kunde erstellen
    kunde = Kunde("Max")
    
    while True:
        # Nutzer wählt eine Aktion
        print("\nWählen Sie eine Aktion: 1 = Fahrrad kaufen, 2 = Fahrrad mieten, 3 = Fahrrad zurückgeben, 4 = Bestand anzeigen, 5 = Beenden")
        aktion = input("Eingabe: ")
        
        if aktion == "5":
            print("Programm beendet.")
            break
        
        if aktion == "4":
            laden.anzeigen_bestand()
            continue
        
        print("Wählen Sie ein Fahrrad: 1 = Citybike, 2 = Mountainbike, 3 = Rennrad")
        fahrrad_typ = input("Eingabe: ")
        
        # Fahrradmodell bestimmen
        if fahrrad_typ == "1":
            modell = "citybike"
        elif fahrrad_typ == "2":
            modell = "mountainbike"
        elif fahrrad_typ == "3":
            modell = "rennrad"
        else:
            print("Ungültige Eingabe.")
            continue
        
        # Kaufen, Mieten oder Zurückgeben ausführen
        if aktion == "1":
            fahrrad = laden.fahrrad_verfuegbar(modell)
            if fahrrad:
                kunde.kaufe_fahrrad(fahrrad)
            else:
                print("Fahrrad nicht verfügbar.")
        elif aktion == "2":
            fahrrad = laden.fahrrad_verfuegbar(modell)
            if fahrrad:
                tage = int(input("Wie viele Tage möchten Sie das Fahrrad mieten? "))
                kunde.miete_fahrrad(fahrrad, tage)
            else:
                print("Kein verfügbares Fahrrad dieses Typs.")
        elif aktion == "3":
            tage_zu_spaet = int(input("Wie viele Tage zu spät wird das Fahrrad zurückgegeben? "))
            kunde.rueckgabe_fahrrad(modell, tage_zu_spaet)
        else:
            print("Ungültige Eingabe.")
    
if __name__ == "__main__":
    main()