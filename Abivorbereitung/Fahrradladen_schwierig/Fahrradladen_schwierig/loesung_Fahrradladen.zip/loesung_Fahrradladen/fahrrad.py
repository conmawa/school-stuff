# fahrrad.py (Basisklasse Fahrrad)
from abc import ABC, abstractmethod

class Fahrrad(ABC):
    def __init__(self, marke, modell, preis, mietgebuehr):
        self.__marke = marke  # Marke des Fahrrads (z. B. Cube, Giant)
        self.__modell = modell  # Modell des Fahrrads (z. B. Citybike, Mountainbike)
        self.__preis = preis  # Kaufpreis des Fahrrads
        self.__mietgebuehr = mietgebuehr  # Mietkosten pro Tag
        self.verfuegbar = True  # Fahrrad ist standardmäßig verfügbar
    
    # Getter-Methoden für die Attribute
    def get_marke(self):
        return self.__marke
    
    def get_modell(self):
        return self.__modell
    
    def get_preis(self):
        return self.__preis
    
    def get_mietgebuehr(self):
        return self.__mietgebuehr
    
    # Abstrakte Methode für Fahrradinfo
    @abstractmethod
    def fahrrad_info(self):
        pass