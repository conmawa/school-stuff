# mountainbike.py (Unterklasse Mountainbike)
from fahrrad import Fahrrad

class Mountainbike(Fahrrad):
    def __init__(self, marke, preis):
        super().__init__(marke, "Mountainbike", preis, mietgebuehr=15)  # Mountainbikes sind teurer
        self.federung = "Vollfederung"  # Standardmäßig Vollfederung
    
    def fahrrad_info(self):
        return f"{self.get_marke()} {self.get_modell()} - Federung: {self.federung}"