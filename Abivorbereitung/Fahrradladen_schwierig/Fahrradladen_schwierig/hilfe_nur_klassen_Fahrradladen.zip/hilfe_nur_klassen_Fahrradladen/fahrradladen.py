# fahrradladen.py (Lagerbestand und Verwaltung)
class Fahrradladen:
    def __init__(self):
        pass
    
    def neues_fahrrad_hinzufuegen(self, fahrrad):
        pass
    
    def fahrrad_verfuegbar(self, modell):
        pass
    
    def anzeigen_bestand(self):
        pass