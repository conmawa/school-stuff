# fahrrad.py (Basisklasse Fahrrad)
from abc import ABC, abstractmethod

class Fahrrad(ABC):
    def __init__(self, marke, modell, preis, mietgebuehr):
        pass
    
    # Getter-Methoden für die Attribute
    def get_marke(self):
        pass
    
    def get_modell(self):
        pass
    
    def get_preis(self):
        pass
    
    def get_mietgebuehr(self):
        pass
    
    # Abstrakte Methode für Fahrradinfo
    @abstractmethod
    def fahrrad_info(self):
        pass #hier bleibt pass unt Unterklassen überschreiben die Methode