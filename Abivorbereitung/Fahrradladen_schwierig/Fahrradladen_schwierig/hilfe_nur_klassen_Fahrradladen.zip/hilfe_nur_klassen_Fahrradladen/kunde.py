
# kunde.py (Kunden-Klasse)
class Kunde:
    def __init__(self, name):
        pass
    
    def kaufe_fahrrad(self, fahrrad):
        pass
    
    def miete_fahrrad(self, fahrrad, tage):
        pass
    
    def rueckgabe_fahrrad(self, modell, tage_zu_spaet):
        pass