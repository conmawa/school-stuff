# rennrad.py (Unterklasse Rennrad)
from fahrrad import Fahrrad

class Rennrad(Fahrrad):
    def __init__(self, marke, preis):
        pass
    
    def fahrrad_info(self):
        pass