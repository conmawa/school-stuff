# main.py (Hauptprogramm)
from citybike import Citybike
from mountainbike import Mountainbike
from rennrad import Rennrad
from kunde import Kunde
from fahrradladen import Fahrradladen

def main():
    pass
    
if __name__ == "__main__":
    main()