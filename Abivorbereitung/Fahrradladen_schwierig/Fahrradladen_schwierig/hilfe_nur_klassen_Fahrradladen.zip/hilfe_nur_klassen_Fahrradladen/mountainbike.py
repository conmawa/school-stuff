# mountainbike.py (Unterklasse Mountainbike)
from fahrrad import Fahrrad

class Mountainbike(Fahrrad):
    def __init__(self, marke, preis):
        pass
    
    def fahrrad_info(self):
        pass