# citybike.py (Unterklasse Citybike)
from fahrrad import Fahrrad

class Citybike(Fahrrad):
    def __init__(self, marke, preis):
        pass
    
    def fahrrad_info(self):
        pass